from django.apps import AppConfig


class ExerciseConfig(AppConfig):
    name = 'exercise'
