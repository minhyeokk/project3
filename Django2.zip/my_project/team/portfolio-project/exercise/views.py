from django.shortcuts import render

from .models import Exercise
# Create your views here.
def exercises(request):
	exercises = Exercise.objects
	return render(request,'exercises.html',{'exercises':exercises})